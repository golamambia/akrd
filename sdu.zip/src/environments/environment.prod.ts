export const environment = {
  production: true
};
export const host = 'https://consult-trico.com/erpstagging/api/';
export const image_path = 'https://consult-trico.com/erpstagging/';
export const logval = {
  production: 'not'
};
