(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_attendence-b_attendence-b_module_ts"],{

/***/ 85995:
/*!*************************************************************!*\
  !*** ./src/app/attendence-b/attendence-b-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBPageRoutingModule": () => (/* binding */ AttendenceBPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _attendence_b_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-b.page */ 9586);




const routes = [
    {
        path: '',
        component: _attendence_b_page__WEBPACK_IMPORTED_MODULE_0__.AttendenceBPage
    }
];
let AttendenceBPageRoutingModule = class AttendenceBPageRoutingModule {
};
AttendenceBPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendenceBPageRoutingModule);



/***/ }),

/***/ 99306:
/*!*****************************************************!*\
  !*** ./src/app/attendence-b/attendence-b.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBPageModule": () => (/* binding */ AttendenceBPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _attendence_b_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-b-routing.module */ 85995);
/* harmony import */ var _attendence_b_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-b.page */ 9586);







let AttendenceBPageModule = class AttendenceBPageModule {
};
AttendenceBPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendence_b_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendenceBPageRoutingModule
        ],
        declarations: [_attendence_b_page__WEBPACK_IMPORTED_MODULE_1__.AttendenceBPage]
    })
], AttendenceBPageModule);



/***/ }),

/***/ 9586:
/*!***************************************************!*\
  !*** ./src/app/attendence-b/attendence-b.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBPage": () => (/* binding */ AttendenceBPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendence_b_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendence-b.page.html */ 26093);
/* harmony import */ var _attendence_b_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-b.page.scss */ 45489);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 58361);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _component_attendance_popover_attendance_popover_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../component/attendance-popover/attendance-popover.component */ 96980);




//import { Http, Headers, RequestOptions } from '@angular/http';













let AttendenceBPage = class AttendenceBPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe, actionSheetController, popoverController
    //public events: Events
    ) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.actionSheetController = actionSheetController;
        this.popoverController = popoverController;
        this.today = new Date().toISOString();
        this.today_date = new Date();
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.name = '';
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_work_time = '';
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.checkin = 0;
        this.leave_check = '';
        this.holiday_check = '';
        this.assign_check = '';
        this.attendence_status = 0;
        this.attendence_statusmsg = '';
        this.checkinFirststaus = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        //this.storage.clear();
    }
    submit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: 'Sending...'
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            if (this.name == '' && this.name == null) {
                this.alertController.create({
                    message: 'Enter name',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
                loading.dismiss();
            }
            else {
                const alert = yield this.alertController.create({
                    message: 'Are you sure to final submit',
                    buttons: [
                        {
                            text: 'Cancel',
                            role: 'cancel',
                            cssClass: 'secondary',
                            handler: (blah) => {
                                //console.log('Confirm Cancel: blah');
                            }
                        },
                        {
                            text: 'Okay',
                            handler: () => {
                                loading.present();
                                //var data ={}
                                var data = {
                                    "ua_createdBy": this.userId,
                                    "deposit_data": this.depositData,
                                    //this.password
                                };
                                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-add', JSON.stringify(data), { headers: headers })
                                    .subscribe((res) => {
                                    // console.log(res);
                                    loading.dismiss();
                                    if (res.status == true) {
                                        this.storage.remove("attendencebData");
                                        this.depositData = [];
                                        this.total_work_time = '';
                                        this.reloadDepositData();
                                        this.alertController.create({
                                            message: 'Attendence successful',
                                            buttons: ['OK']
                                        }).then(resalert => {
                                            resalert.present();
                                        });
                                    }
                                    else {
                                        this.alertController.create({
                                            message: 'Something went wrong',
                                            buttons: ['OK']
                                        }).then(resalert => {
                                            resalert.present();
                                        });
                                        loading.dismiss();
                                    }
                                }, (err) => {
                                    //console.log(err);
                                    loading.dismiss();
                                });
                            }
                        }
                    ]
                });
                yield alert.present();
            }
        });
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    importFile(event, index) {
        console.log(event);
        if (event.target.files && event.target.files.length > 0) {
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            var fileName = files[0].name.toUpperCase();
            this.document[index] = files[0];
            // if (fileName.endsWith(".JPG") || fileName.endsWith(".JPEG") || fileName.endsWith(".PNG")) {
            //   //console.log(files[0]);
            //   this.document[index] = files[0];
            // } else {
            //  this.document[index] = null;
            // }
        }
    }
    ionViewWillEnter() {
        // this.reloadDepositData();
        //this.storage.clear();
        //this.storage.set("checkin",0);
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                // this.getUser();
                //this.getData(); 
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
        // this.checkin_check();
    }
    ionViewDidEnter() {
        // this.checkin_check();
        //this.getData(); 
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                // this.getUser();
                this.getData();
                //this.reloadDepositData();
            }
        });
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/user-attendense-list', {
            // clientName: 'test',
            }]);
    }
    checkin_check() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.get("checkin").then((val) => {
                if (val) {
                    //  this.checkin=1;
                    //console.log(val);
                }
                else {
                    // this.checkin=0;
                }
            });
        });
    }
    reloadDepositData2() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            // this.checkin_check();
            //let d
            // console.log(1234);
            yield this.storage.forEach((value, key, index) => {
                if (key == 'attendencebData') {
                    // console.log(value);
                    var milliseconds = 0;
                    var lngth = 0;
                    this.depositData = value;
                    value.forEach(element => {
                        if (element.end_time && element.start_time) {
                            var parsedServerOutTime = moment__WEBPACK_IMPORTED_MODULE_4__(element.end_time24, "HH:mm");
                            var parsedServerInTime = moment__WEBPACK_IMPORTED_MODULE_4__(element.start_time24, "HH:mm");
                            milliseconds += parsedServerOutTime.diff(parsedServerInTime) / 1000;
                            lngth += 1;
                            if (value.length == lngth) {
                                let hours = Math.floor(milliseconds / 3600); // get hours
                                let minutes = Math.floor((milliseconds - (hours * 3600)) / 60);
                                if (hours) {
                                    this.total_work_time = Math.abs(hours) + ' hrs ' + Math.abs(minutes) + ' min';
                                    this.total_work_hrs = Math.abs(hours);
                                    this.total_work_min = Math.abs(minutes);
                                }
                                else {
                                    this.total_work_time = Math.abs(minutes) + ' mins';
                                    this.total_work_hrs = Math.abs(hours);
                                    this.total_work_min = Math.abs(minutes);
                                }
                            }
                            //console.log(lngth);
                            //let min=
                        }
                    });
                }
            });
        });
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": '',
                "search_date": this.datePipe.transform(this.today_date, 'yyyy-MM-dd'),
                "checkout": '1'
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                }
                else {
                    this.depositData = res.response_data;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    addAttendence() {
        this.navCtrl.navigateForward(['/attendence-b-add', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-b-edit', {
                index: i,
            }]);
    }
    edit_attendence2(i, data) {
        this.navCtrl.navigateForward(['/attendence-b-update', {
                index: i,
            }]);
    }
    remove_attendence(id, chk) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(chk);
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendencebData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.total_work_time = '';
                                                }
                                                this.storage.set('attendencebData', this.depositData).then((r) => {
                                                    if (chk != 0) {
                                                        this.checkin = 0;
                                                        this.storage.set("checkin", 0).then((r) => {
                                                            this.reloadDepositData();
                                                            //console.log('A');
                                                        });
                                                    }
                                                    else {
                                                        this.reloadDepositData();
                                                        //console.log('b');
                                                    }
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    getData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": '',
                "search_date": this.datePipe.transform(this.today_date, 'yyyy-MM-dd'),
                "checkout": '1'
                //this.password
            };
            yield loading.present();
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'assign-leave-check', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                console.log(res);
                loading.dismiss();
                var null_attendance = 0;
                if (res.status == true) {
                    this.depositData = res.get_attendance;
                    this.holiday_check = res.holiday_leave;
                    this.assign_check = res.assign_leave;
                    for (let ga of res.get_attendance) {
                        if (ga.ua_checkouttime == '') {
                            null_attendance += 1;
                        }
                    }
                    // console.log(null_attendance);
                    if (res.user_details.log_status) {
                        this.checkinFirststaus = 1;
                    }
                    else {
                        this.checkinFirststaus = 0;
                    }
                    if (this.holiday_check.length) {
                        if (this.assign_check.length) {
                            this.attendence_status = 1;
                            this.attendence_statusmsg = '';
                            this.checkin = null_attendance;
                        }
                        else {
                            this.attendence_status = 0;
                            this.attendence_statusmsg = 'Today is holiday';
                        }
                    }
                    else {
                        this.attendence_statusmsg = '';
                        this.attendence_status = 1;
                        this.checkin = null_attendance;
                    }
                }
                else {
                    this.depositData = res.get_attendance;
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    checkinFirst() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'attendence-checkin-first', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.checkinFirststaus = 1;
                }
                else {
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getUser() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'get-user-details', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    if (res.response_data.log_status) {
                        this.checkinFirststaus = 1;
                    }
                    else {
                        this.checkinFirststaus = 0;
                    }
                    //this.checkinFirststaus=1;
                }
                else {
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    remove_expense(id, checkin) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    },
                    {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            loading.present();
                            let localarray = {
                                "userid": this.userId,
                                "id": id,
                                //"address":this.address,
                            };
                            //console.log(this.end_time);
                            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-deletebyid', JSON.stringify(localarray), { headers: headers })
                                .subscribe((res) => {
                                // console.log(res);
                                loading.dismiss();
                                if (res.status == true) {
                                    if (checkin == 1) {
                                        this.storage.set("checkin", 0);
                                        this.checkin = 0;
                                    }
                                    this.reloadDepositData();
                                    this.alertController.create({
                                        message: 'Successfully deleted',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                }
                                else {
                                    this.alertController.create({
                                        message: 'Something went wrong',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                    loading.dismiss();
                                }
                            }, (err) => {
                                //console.log(err);
                                loading.dismiss();
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    detailsView(desc, locin, locout, project) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            var button_array = [
                { text: 'Project : ' + project },
                { text: 'Description : ' + desc },
                { text: 'Location in : ' + locin },
                { text: 'Location out : ' + locout },
            ];
            //  if(rejt){
            // button_array.push({ text: 'Reject reason : '+rejt });
            // }
            const actionSheet = yield this.actionSheetController.create({
                header: "Short Details",
                cssClass: 'my-custom-class',
                buttons: button_array,
            });
            yield actionSheet.present();
        });
    }
    settingsPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const siteInfo = { id: 1, name: 'edupala' };
            const popover = yield this.popoverController.create({
                component: _component_attendance_popover_attendance_popover_component__WEBPACK_IMPORTED_MODULE_5__.AttendancePopoverComponent,
                event: ev,
                cssClass: 'popover_setting',
                componentProps: {
                    site: siteInfo
                },
                translucent: true
            });
            popover.onDidDismiss().then((result) => {
                //console.log(result.data);
            });
            return yield popover.present();
            /** Sync event from popover component */
        });
    }
};
AttendenceBPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_10__.DatePipe },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.PopoverController }
];
AttendenceBPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-attendence-b',
        template: _raw_loader_attendence_b_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendence_b_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendenceBPage);



/***/ }),

/***/ 96980:
/*!******************************************************************************!*\
  !*** ./src/app/component/attendance-popover/attendance-popover.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendancePopoverComponent": () => (/* binding */ AttendancePopoverComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendance_popover_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendance-popover.component.html */ 24883);
/* harmony import */ var _attendance_popover_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendance-popover.component.scss */ 30543);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 34595);





let AttendancePopoverComponent = class AttendancePopoverComponent {
    constructor(popoverController, navCtrl) {
        this.popoverController = popoverController;
        this.navCtrl = navCtrl;
    }
    ngOnInit() { }
    popDismiss(page) {
        this.popoverController.dismiss();
        this.navCtrl.navigateForward('/' + page);
    }
};
AttendancePopoverComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
AttendancePopoverComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-attendance-popover',
        template: _raw_loader_attendance_popover_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendance_popover_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendancePopoverComponent);



/***/ }),

/***/ 45489:
/*!*****************************************************!*\
  !*** ./src/app/attendence-b/attendence-b.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-grid {\n  margin-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.add-btn {\n  --ion-color-base: #071662 !important;\n  --ion-color-base-rgb: var(--ion-color-primary-rgb, 56, 128, 255) !important;\n  --ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;\n  --ion-color-contrast-rgb: var(\n    --ion-color-primary-contrast-rgb,\n    255,\n    255,\n    255\n  ) !important;\n  --ion-color-shade: #071662 !important;\n  --ion-color-tint: #071662 !important;\n}\n\n.add-btn-icon {\n  color: #3bf5c2;\n  font-size: 30px;\n}\n\n.ref_btn {\n  padding-top: 8px !important;\n  padding-left: 9px !important;\n  border-radius: 9px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF0dGVuZGVuY2UtYi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFLG9DQUFBO0VBQ0EsMkVBQUE7RUFDQSx3RUFBQTtFQUNBOzs7OztjQUFBO0VBTUEscUNBQUE7RUFDQSxvQ0FBQTtBQUVGOztBQUFBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtBQUlGIiwiZmlsZSI6ImF0dGVuZGVuY2UtYi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTBweDtcclxufVxyXG4uYWRkLWJ0biB7XHJcbiAgLS1pb24tY29sb3ItYmFzZTogIzA3MTY2MiAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IsIDU2LCAxMjgsIDI1NSkgIWltcG9ydGFudDtcclxuICAtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QsICNmZmYpICFpbXBvcnRhbnQ7XHJcbiAgLS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoXHJcbiAgICAtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0LXJnYixcclxuICAgIDI1NSxcclxuICAgIDI1NSxcclxuICAgIDI1NVxyXG4gICkgIWltcG9ydGFudDtcclxuICAtLWlvbi1jb2xvci1zaGFkZTogIzA3MTY2MiAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLXRpbnQ6ICMwNzE2NjIgIWltcG9ydGFudDtcclxufVxyXG4uYWRkLWJ0bi1pY29uIHtcclxuICBjb2xvcjogIzNiZjVjMjtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbn1cclxuLnJlZl9idG4ge1xyXG4gIHBhZGRpbmctdG9wOiA4cHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWxlZnQ6IDlweCAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDlweCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 30543:
/*!********************************************************************************!*\
  !*** ./src/app/component/attendance-popover/attendance-popover.component.scss ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdHRlbmRhbmNlLXBvcG92ZXIuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 26093:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/attendence-b/attendence-b.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-buttons slot=\"primary\">\n  <ion-button (click)=\"settingsPopover()\">\n    <ion-icon style=\"color:white;\" slot=\"icon-only\" ios=\"ellipsis-horizontal\" md=\"ellipsis-vertical\"></ion-icon>\n  </ion-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Attendance Data</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n\n    <ion-grid>\n       \n             \n              <span *ngIf=\"attendence_status\">\n                <ion-row class=\"margin\" >\n                <ion-col size=\"12\" *ngIf=\"!checkin\">\n                  <div class=\"ion-text-center\">\n                  <ion-button class=\"add-btn\" color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                    <ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"add-btn-icon\"></ion-icon>\n                    Add Attendance\n                  </ion-button>\n                </div>\n                </ion-col>\n              </ion-row>\n  \n              </span>\n\n       \n            \n            <ion-row class=\"margin\"  *ngIf=\"attendence_statusmsg\">\n             \n              <ion-col size=\"12\" >\n                <div class=\"ion-text-center\">\n                <ion-button color=\"warning\" fill=\"outline\" >\n                  \n                 {{attendence_statusmsg}}\n                </ion-button>\n              </div>\n              </ion-col>\n           \n\n            </ion-row>\n            <div *ngFor=\"let inneritem of depositData; let i = index\" class=\"card-box\" style=\"padding-left: 0;\">\n                  \n              <ion-row >\n               \n                <ion-col size=\"1\"  class=\"{{ inneritem.ua_checkouttime!= '' ? 'active-col' : 'inactive-col'}}\" (click)=\"detailsView(inneritem.uwe_description,inneritem.uwe_reject)\">\n                  <h4 class=\"status-title\"><ion-badge  class=\"ion-badgeatn-suc\" *ngIf=\"inneritem.ua_checkouttime\" >Success</ion-badge>\n                    <ion-badge class=\"ion-badge\" *ngIf=\"!inneritem.ua_checkouttime\" >Pending</ion-badge>\n                    </h4>\n                \n                </ion-col>\n                <ion-col size=\"11\" style=\"padding-left:11px\">\n                <ion-label class=\"nomargin\">  \n                  <ion-row (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout,inneritem.project_name)\">\n                    <ion-col size=\"8\">\n                      <h2 class=\"list-title\"><span class=\"smspan\">Project </span><br>\n                        {{inneritem.project_name.length > 50 ? inneritem.project_name.slice(0, 50) + \"...\" : inneritem.project_name }}\n                      </h2>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                      <h2 class=\"list-title\"><span class=\"smspan\"> Category </span><br>\n                        {{inneritem.category_name}}\n                      </h2>\n                    </ion-col>\n                                          \n                    \n                  </ion-row>\n                  <ion-row>\n                    <ion-col size=\"4\">\n                      <h2 class=\"list-title\"><span class=\"smspan\"> Date </span><br>\n                        {{inneritem.ua_checkindate | date:'MMM dd, yy'}}\n                      </h2>\n                    </ion-col> \n                    <ion-col size=\"4\" (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout)\">\n                      <h2 class=\"list-title\"><span class=\"smspan\"> Check In </span><br>\n                        {{inneritem.ua_checkintime}}\n                      </h2>\n                    </ion-col>\n                    <ion-col size=\"4\" (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout)\">\n                      <h2 class=\"list-title\"><span class=\"smspan\"> Check Out </span><br>\n                       {{inneritem.ua_checkouttime}}\n                      </h2>\n                    </ion-col>\n                    <ion-col size=\"5\" >\n                      <ion-button color=\"primary\" expand=\"block\" size=\"small\" fill=\"outline\" *ngIf=\"inneritem.ua_checkouttime\"  (click)=\"edit_attendence2(inneritem.ua_id,inneritem)\">\n                        <ion-icon slot=\"start\" name=\"create-outline\"></ion-icon>\n                        Edit\n                      </ion-button>\n                      <ion-button color=\"primary\" expand=\"block\" size=\"small\" fill=\"outline\" *ngIf=\"!inneritem.ua_checkouttime\"  (click)=\"edit_attendence(inneritem.ua_id,inneritem)\">\n                        <ion-icon slot=\"start\" name=\"create-outline\"></ion-icon>\n                        Edit\n                      </ion-button>\n          \n                    </ion-col>\n                    <ion-col size=\"5\">\n                      <ion-button expand=\"block\" size=\"small\" fill=\"outline\" color=\"danger\" *ngIf=\"inneritem.ua_checkouttime\" (click)=\"remove_expense(inneritem.ua_id,0)\">\n                        <ion-icon slot=\"start\" name=\"trash-outline\"></ion-icon>\n                        Delete\n                      </ion-button>\n                      <ion-button expand=\"block\" size=\"small\" fill=\"outline\" color=\"danger\" *ngIf=\"!inneritem.ua_checkouttime\" (click)=\"remove_expense(inneritem.ua_id,1)\">\n                        <ion-icon slot=\"start\" name=\"trash-outline\"></ion-icon>\n                        Delete\n                      </ion-button>\n                    \n                      </ion-col>\n                      \n                        </ion-row>\n                  </ion-label>\n                </ion-col>\n              \n            \n          </ion-row>\n       \n          </div>\n             \n\n    </ion-grid>\n    \n \n</ion-content>");

/***/ }),

/***/ 24883:
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/component/attendance-popover/attendance-popover.component.html ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n\t<ion-item  (click)=\"popDismiss('home')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"home-outline\" class=\"item-icon\"></ion-icon>Home\n\t</ion-item>\n\t<ion-item  (click)=\"popDismiss('user-attendense-list')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"list-outline\" class=\"item-icon\"></ion-icon>All Attendance\n\t</ion-item>\n\t\n\t \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_attendence-b_attendence-b_module_ts.js.map