(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_user-attendense-list_user-attendense-list_module_ts"],{

/***/ 54825:
/*!******************************************************************************************!*\
  !*** ./src/app/component/myattendancelist-popover/myattendancelist-popover.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyattendancelistPopoverComponent": () => (/* binding */ MyattendancelistPopoverComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_myattendancelist_popover_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./myattendancelist-popover.component.html */ 89878);
/* harmony import */ var _myattendancelist_popover_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myattendancelist-popover.component.scss */ 10783);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 34595);





let MyattendancelistPopoverComponent = class MyattendancelistPopoverComponent {
    constructor(popoverController, navCtrl) {
        this.popoverController = popoverController;
        this.navCtrl = navCtrl;
    }
    ngOnInit() { }
    popDismiss(page) {
        this.popoverController.dismiss();
        this.navCtrl.navigateForward('/' + page);
    }
};
MyattendancelistPopoverComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
MyattendancelistPopoverComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-myattendancelist-popover',
        template: _raw_loader_myattendancelist_popover_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_myattendancelist_popover_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MyattendancelistPopoverComponent);



/***/ }),

/***/ 60029:
/*!*****************************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPageRoutingModule": () => (/* binding */ UserAttendenseListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-attendense-list.page */ 59832);




const routes = [
    {
        path: '',
        component: _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_0__.UserAttendenseListPage
    }
];
let UserAttendenseListPageRoutingModule = class UserAttendenseListPageRoutingModule {
};
UserAttendenseListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserAttendenseListPageRoutingModule);



/***/ }),

/***/ 52746:
/*!*********************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPageModule": () => (/* binding */ UserAttendenseListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _user_attendense_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-attendense-list-routing.module */ 60029);
/* harmony import */ var _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-attendense-list.page */ 59832);







let UserAttendenseListPageModule = class UserAttendenseListPageModule {
};
UserAttendenseListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_attendense_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserAttendenseListPageRoutingModule
        ],
        declarations: [_user_attendense_list_page__WEBPACK_IMPORTED_MODULE_1__.UserAttendenseListPage]
    })
], UserAttendenseListPageModule);



/***/ }),

/***/ 59832:
/*!*******************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPage": () => (/* binding */ UserAttendenseListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_user_attendense_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-attendense-list.page.html */ 27790);
/* harmony import */ var _user_attendense_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-attendense-list.page.scss */ 62871);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _component_myattendancelist_popover_myattendancelist_popover_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../component/myattendancelist-popover/myattendancelist-popover.component */ 54825);




//import { Http, Headers, RequestOptions } from '@angular/http';












let UserAttendenseListPage = class UserAttendenseListPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe, actionSheetController, popoverCtrl, popoverController
    //public events: Events
    ) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.actionSheetController = actionSheetController;
        this.popoverCtrl = popoverCtrl;
        this.popoverController = popoverController;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.project_list = '';
        this.search_project = '';
        this.search_date = '';
        this.customPickerOptionFrom = {
            buttons: [
                {
                    text: 'clear',
                    handler: () => {
                        this.search_date = '';
                        this.reloadDepositData();
                        //this.ionCancel.emit();
                    }
                },
                {
                    text: 'cancel',
                    role: 'cancel',
                    handler: () => {
                        //console.log(123);
                    }
                },
                {
                    text: 'Done',
                    handler: (data) => {
                        // console.log(data);
                        var dt = data.year.value + '-' + data.month.value + '-' + data.day.value;
                        //convertDataToISO(this.datetimeValue);
                        this.search_date = dt;
                        //this.datePipe.transform(dt, 'Y-MM-dd');
                        this.reloadDepositData();
                        // console.log(this.search_date);
                    }
                }
            ]
        };
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.getprojectList();
                this.reloadDepositData();
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //event.target.complete();
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": this.search_project,
                "search_date": this.search_date,
                "checkout": ''
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                event.target.complete();
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": this.search_project,
                "search_date": this.search_date,
                "checkout": ''
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.project_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectProject(id) {
        this.search_project = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectDate(dt) {
        //this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(dt);
        // this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    detailsView(desc, locin, locout, project) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var button_array = [
                { text: 'Project : ' + project },
                { text: 'Description : ' + desc },
                { text: 'Location in : ' + locin },
                { text: 'Location out : ' + locout },
            ];
            //  if(rejt){
            // button_array.push({ text: 'Reject reason : '+rejt });
            // }
            const actionSheet = yield this.actionSheetController.create({
                header: "Short Details",
                cssClass: 'my-custom-class',
                buttons: button_array,
            });
            yield actionSheet.present();
        });
    }
    settingsPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const siteInfo = { id: 1, name: 'edupala' };
            const popover = yield this.popoverController.create({
                component: _component_myattendancelist_popover_myattendancelist_popover_component__WEBPACK_IMPORTED_MODULE_4__.MyattendancelistPopoverComponent,
                event: ev,
                cssClass: 'popover_setting',
                componentProps: {
                    site: siteInfo
                },
                translucent: true
            });
            popover.onDidDismiss().then((result) => {
                //console.log(result.data);
            });
            return yield popover.present();
            /** Sync event from popover component */
        });
    }
};
UserAttendenseListPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController }
];
UserAttendenseListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-user-attendense-list',
        template: _raw_loader_user_attendense_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_attendense_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserAttendenseListPage);



/***/ }),

/***/ 10783:
/*!********************************************************************************************!*\
  !*** ./src/app/component/myattendancelist-popover/myattendancelist-popover.component.scss ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJteWF0dGVuZGFuY2VsaXN0LXBvcG92ZXIuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 62871:
/*!*********************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-grid {\n  margin-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.form-group {\n  margin: 0 0 10px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItYXR0ZW5kZW5zZS1saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUNBO0VBQ0UsMkJBQUE7QUFFRiIsImZpbGUiOiJ1c2VyLWF0dGVuZGVuc2UtbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTBweDtcclxufVxyXG4uZm9ybS1ncm91cCB7XHJcbiAgbWFyZ2luOiAwIDAgMTBweCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 89878:
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/component/myattendancelist-popover/myattendancelist-popover.component.html ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n\t<ion-item  (click)=\"popDismiss('home')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"home-outline\" class=\"item-icon\"></ion-icon>Home\n\t</ion-item>\n\t<ion-item  (click)=\"popDismiss('attendence-b')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"item-icon\"></ion-icon>Add Attendance\n\t</ion-item>\n\t\n\t \n</ion-content>");

/***/ }),

/***/ 27790:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-attendense-list/user-attendense-list.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-buttons slot=\"primary\">\n  <ion-button (click)=\"settingsPopover()\">\n    <ion-icon style=\"color:white;\" slot=\"icon-only\" ios=\"ellipsis-horizontal\" md=\"ellipsis-vertical\"></ion-icon>\n  </ion-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Attendance</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n  <ion-refresher (ionRefresh)=\"doRefresh($event)\" slot=\"fixed\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content style=\"margin-top: 150px;\"></ion-refresher-content>\n  </ion-refresher>\n    <ion-grid>\n      <div class=\"card-box\" style=\"padding-top: 11px;\">\n        <ion-row >\n          <ion-col align-self-center size=\"6\" >\n            <div class=\"form-group\">\n              <label>Project</label>\n               <select #P (change)=\"selectProject(P.value)\" class=\"form-control\" [(ngModel)]=\"search_project\" [ngModelOptions]=\"{standalone: true}\">\n              <option value=\"\" selected=\"selected\">Select all</option>\n              <!-- <option *ngFor=\"let val of project_list; let i = index\" value=\"{{val.ID}}\">{{val.project_id}} > {{val.sub_project_id}}</option> -->\n              <option *ngFor=\"let val of project_list; let i = index\" value=\"{{val.sub_project_id}}\">{{val.project_name+' ('+val.project_id+')'}} > {{val.sub_project_name+' ('+val.sub_project_id+')'}}  </option>\n            </select>\n              <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n          </div>\n           \n          \n     </ion-col>\n     <ion-col align-self-center size=\"6\" >\n      <div class=\"form-group\"  >\n        <label class=\"time-lable\">Date</label>\n      <!-- <input class=\"form-control\" type=\"date\" #D (change)=\"selectDate(D.value)\" [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\"> -->\n        <ion-datetime [pickerOptions]=\"customPickerOptionFrom\" #D (ionChange)=\"selectDate(D.value)\" class=\"form-control\" placeholder=\"Date (D/M/Y)\" [min]=\"minDate\"  displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n      </div>\n      \n   \n    </ion-col>\n    </ion-row>\n    </div>\n    \n  <div *ngFor=\"let inneritem of depositData; let i = index\" class=\"card-box\" style=\"padding-left: 0;\">\n                  \n    <ion-row >\n     \n      <ion-col size=\"1\"  class=\"{{ inneritem.ua_checkouttime!= '' ? 'active-col' : 'inactive-col'}}\" (click)=\"detailsView(inneritem.uwe_description,inneritem.uwe_reject)\">\n        <h4 class=\"status-title\"><ion-badge  class=\"ion-badgeatnlist-suc\" *ngIf=\"inneritem.ua_checkouttime\" >Success</ion-badge>\n          <ion-badge class=\"ion-badgeatn-pen\" *ngIf=\"!inneritem.ua_checkouttime\" >Pending</ion-badge>\n          </h4>\n      \n      </ion-col>\n      <ion-col size=\"11\" style=\"padding-left:11px\">\n      <ion-label class=\"nomargin\">  \n        <ion-row (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout,inneritem.project_name)\">\n          <ion-col size=\"8\">\n            <h2 class=\"list-title\"><span class=\"smspan\">Project </span><br>\n              {{inneritem.project_name.length > 50 ? inneritem.project_name.slice(0, 50) + \"...\" : inneritem.project_name }}\n            </h2>\n          </ion-col>\n          <ion-col size=\"4\">\n            <h2 class=\"list-title\"><span class=\"smspan\"> Category </span><br>\n              {{inneritem.category_name}}\n            </h2>\n          </ion-col>\n                                \n          \n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h2 class=\"list-title\"><span class=\"smspan\"> Date </span><br>\n              {{inneritem.ua_checkindate | date:'MMM dd, yy'}}\n            </h2>\n          </ion-col> \n          <ion-col size=\"4\" (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout)\">\n            <h2 class=\"list-title\"><span class=\"smspan\"> Check In </span><br>\n              {{inneritem.ua_checkintime}}\n            </h2>\n          </ion-col>\n          <ion-col size=\"4\" (click)=\"detailsView(inneritem.ua_description,inneritem.ua_locationin,inneritem.ua_locationout)\">\n            <h2 class=\"list-title\"><span class=\"smspan\"> Check Out </span><br>\n             {{inneritem.ua_checkouttime}}\n            </h2>\n          </ion-col>\n          \n            \n              </ion-row>\n        </ion-label>\n      </ion-col>\n    \n  \n</ion-row>\n\n</div>\n  <div *ngIf=\"!depositData.length\">\n\n    <ion-row>\n      <ion-col size=\"12\">\n<h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n         \n        </h2>\n        </ion-col>\n        </ion-row>\n  </div>\n            \n          \n    </ion-grid>\n\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_user-attendense-list_user-attendense-list_module_ts.js.map