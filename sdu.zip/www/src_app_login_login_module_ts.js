(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_login_login_module_ts"],{

/***/ 90795:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 93721);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 77641:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 90795);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 93721);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 93721:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.page.html */ 76770);
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss */ 21339);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var src_app_event_events_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/event/events.service */ 1479);












let LoginPage = class LoginPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, events) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.events = events;
        this.isLoading = false;
        this.isActive = true;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.navCtrl.navigateForward('home');
            }
        });
    }
    ngOnInit() {
        this.storage.create();
    }
    login() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Checking...'
            });
            const alert = yield this.alertController.create({
                message: 'Username and Password is wrong',
                buttons: ['OK']
            });
            const usernamealrt = yield this.alertController.create({
                message: 'Please enter username',
                buttons: ['OK']
            });
            const passalrt = yield this.alertController.create({
                message: 'Please enter password',
                buttons: ['OK']
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //console.log(headers);
            //headers.append('Accept', 'application/json');
            // headers.append('Access-Control-Allow-Origin', '*');
            // headers = headers.append('GET', 'POST');
            //  headers.append('Authorization', 'Basic ' + base64.encode(username + ":" + password));
            //  headers = headers.append("Access-Control-Allow-Origin", "*");
            //  headers = headers.append("Access-Control-Allow-Credentials", "true");
            // headers = headers.append("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
            // headers = headers.append("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
            if (this.email == '' || this.email == null) {
                loading.dismiss();
                usernamealrt.present();
            }
            else if (this.password == '' || this.password == null) {
                loading.dismiss();
                passalrt.present();
            }
            else {
                yield loading.present();
                var data = {
                    "username": this.email,
                    "password": this.password
                    //this.password
                };
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'login', JSON.stringify(data), { headers: headers })
                    .subscribe(res => {
                    this.res = res;
                    //console.log(res);
                    loading.dismiss();
                    if (this.res.status == 0) {
                        this.alertController.create({
                            message: this.res.message,
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                    }
                    else if (this.res.status == 1) {
                        this.storage.set("genuserDetails", this.res.response_data);
                        //this.storage.set("token", this.res.api_token);
                        this.navCtrl.navigateForward('home');
                        this.events.publish('user:login', true);
                        loading.dismiss();
                    }
                    else {
                        //alert("Server error");
                        loading.dismiss();
                    }
                }, (err) => {
                    console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    inputChange(params) {
        if (params == 1) {
            this.isActive = false;
        }
        else {
            this.isActive = true;
        }
        //console.log(params);
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: src_app_event_events_service__WEBPACK_IMPORTED_MODULE_4__.Events }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginPage);



/***/ }),

/***/ 21339:
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css\");\n@import url(\"https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css\");\n@import url(\"https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap\");\nhtml,\nbody {\n  display: block;\n  height: 100%;\n  margin: 0;\n  font-family: \"Raleway\", sans-serif;\n  position: relative;\n  z-index: 1;\n  background-color: #ffffff;\n}\n*,\n::after,\n::before {\n  box-sizing: border-box;\n}\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-family: \"Raleway\", sans-serif;\n}\nimg {\n  max-width: 100%;\n  height: auto;\n}\n.justify-content-between {\n  justify-content: space-between !important;\n}\n.d-flex {\n  display: flex !important;\n}\n.container {\n  box-sizing: border-box;\n  padding: 0px 30px;\n  width: 100%;\n}\n.body_warrper {\n  width: 100%;\n  height: 100vh;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  position: relative;\n  background: #1297e0;\n}\n.apply_for_payout_area {\n  width: 100%;\n  box-sizing: border-box;\n  position: relative;\n}\n.apply_for_payout_area .shape_box {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 469px;\n  box-sizing: border-box;\n  overflow: hidden;\n  z-index: 0;\n}\n.apply_for_payout_area .shape_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.apply_for_payout {\n  width: 100%;\n  padding: 90px 0px;\n  box-sizing: border-box;\n  position: relative;\n  z-index: 1;\n}\n.apply_for_payout h1 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 15px;\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 400;\n  text-align: center;\n}\n.apply_for_payout .form_box {\n  width: 100%;\n  min-height: 358px;\n  box-sizing: border-box;\n  border-radius: 30px;\n  padding: 50px 25px;\n  position: relative;\n  background: #ffffff;\n  box-shadow: 0 5px 5px rgba(146, 146, 146, 0.24);\n  margin: 0 0 30px;\n}\n.form-group, .form-check {\n  width: 100%;\n  box-sizing: border-box;\n  margin: 0 0 20px;\n}\n.form-group label {\n  width: 100%;\n  box-sizing: border-box;\n  margin: 0 0 8px;\n  font-size: 15px;\n  font-weight: 500;\n  color: #000000;\n  letter-spacing: 1px;\n  display: block;\n}\n.form-control {\n  width: 100%;\n  height: 46px;\n  box-sizing: border-box;\n  border: none;\n  border-bottom: 1px solid #bfbfbf;\n  color: #000000;\n  outline: none;\n  font-size: 15px;\n  font-weight: 500;\n  padding: 10px 0px;\n}\ntextarea.form-control {\n  border-radius: 10px;\n  height: 123px;\n}\n.btn {\n  background: #86be41;\n  border: 1px solid #86be41;\n  text-align: center;\n  width: 100%;\n  padding: 10px 15px;\n  outline: none;\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 500;\n  text-transform: uppercase;\n  border-radius: 30px;\n}\n.apply_for_payout .form_box h3 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 25px;\n  color: #000000;\n  font-size: 20px;\n  font-weight: 600;\n  text-align: center;\n}\n.form {\n  width: 100%;\n  box-sizing: border-box;\n  margin: 0 0 20px;\n}\n.form:last-child {\n  margin: 0 0 0;\n}\n.apply_for_payout_area .logo {\n  width: 100%;\n  max-width: 112px;\n  margin: 0 auto 10px;\n}\n.apply_for_payout_area .logo img {\n  width: 100%;\n  object-fit: contain;\n}\n.form-check label.form-check-label {\n  font-size: 14px;\n}\n.btn-link {\n  color: #1ca3ed;\n  font-size: 14px;\n  font-weight: 400;\n  padding: 0 0;\n  border: none;\n  background: transparent;\n  outline: none;\n}\n.form-check .btn-link {\n  float: right;\n}\n.apply_for_payout .account {\n  width: 100%;\n  box-sizing: border-box;\n  text-align: center;\n}\n.apply_for_payout .account p {\n  width: 100%;\n  text-align: center;\n  padding: 0 0;\n  margin: 0 0 2px;\n  font-size: 14px;\n  font-weight: 400;\n  color: #6c6c6c;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBUSx5RkFBQTtBQUNBLCtIQUFBO0FBQ0Esa01BQUE7QUFFUjs7RUFFSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0FBQUo7QUFJQTs7O0VBR0ksc0JBQUE7QUFESjtBQUlBOzs7Ozs7RUFNSSxrQ0FBQTtBQURKO0FBSUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtBQURKO0FBSUE7RUFFSSx5Q0FBQTtBQURKO0FBSUE7RUFFSSx3QkFBQTtBQURKO0FBSUE7RUFDSSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQURKO0FBSUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFESjtBQUlBO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUFESjtBQUlBO0VBQ0ksa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7QUFESjtBQUlBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQURKO0FBSUE7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQURKO0FBSUE7RUFDSSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFESjtBQUlBO0VBQ0ksV0FBQTtFQUNBLGlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0VBQ0EsZ0JBQUE7QUFESjtBQUlBO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFESjtBQUdBO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFBSjtBQUdBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFBSjtBQUVBO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0FBQ0o7QUFDQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUVKO0FBQUE7RUFDSSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFHSjtBQURBO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFJSjtBQUZBO0VBQ0ksYUFBQTtBQUtKO0FBRkE7RUFDSSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUtKO0FBSEE7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7QUFNSjtBQUpBO0VBQ0ksZUFBQTtBQU9KO0FBTEE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7QUFRSjtBQU5BO0VBQ0ksWUFBQTtBQVNKO0FBUEE7RUFDSSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQVVKO0FBUkE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFXSiIsImZpbGUiOiJsb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9jZG5qcy5jbG91ZGZsYXJlLmNvbS9hamF4L2xpYnMvZm9udC1hd2Vzb21lLzUuMTQuMC9jc3MvYWxsLm1pbi5jc3MnKTtcclxuQGltcG9ydCB1cmwoJ2h0dHBzOi8vY2RuanMuY2xvdWRmbGFyZS5jb20vYWpheC9saWJzL21hdGVyaWFsLWRlc2lnbi1pY29uaWMtZm9udC8yLjIuMC9jc3MvbWF0ZXJpYWwtZGVzaWduLWljb25pYy1mb250Lm1pbi5jc3MnKTtcclxuQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UmFsZXdheTppdGFsLHdnaHRAMCwxMDA7MCwyMDA7MCwzMDA7MCw0MDA7MCw1MDA7MCw2MDA7MCw3MDA7MCw4MDA7MCw5MDA7MSwxMDA7MSwyMDA7MSwzMDA7MSw0MDA7MSw1MDA7MSw2MDA7MSw3MDA7MSw4MDA7MSw5MDAmZGlzcGxheT1zd2FwJyk7XHJcblxyXG5odG1sLFxyXG5ib2R5IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgZm9udC1mYW1pbHk6ICdSYWxld2F5Jywgc2Fucy1zZXJpZjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG5cclxufVxyXG5cclxuKixcclxuOjphZnRlcixcclxuOjpiZWZvcmUge1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxufVxyXG5cclxuaDEsXHJcbmgyLFxyXG5oMyxcclxuaDQsXHJcbmg1LFxyXG5oNiB7XHJcbiAgICBmb250LWZhbWlseTogJ1JhbGV3YXknLCBzYW5zLXNlcmlmO1xyXG59XHJcblxyXG5pbWcge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG4uanVzdGlmeS1jb250ZW50LWJldHdlZW4ge1xyXG4gICAgLW1zLWZsZXgtcGFjazoganVzdGlmeSAhaW1wb3J0YW50O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG4gICAgZGlzcGxheTogLW1zLWZsZXhib3ggIWltcG9ydGFudDtcclxuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgcGFkZGluZzogMHB4IDMwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmJvZHlfd2FycnBlciB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwdmg7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgcGFkZGluZzogMCAwIDA7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMTI5N2UwO1xyXG59XHJcblxyXG4uYXBwbHlfZm9yX3BheW91dF9hcmVhIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLmFwcGx5X2Zvcl9wYXlvdXRfYXJlYSAuc2hhcGVfYm94IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNDY5cHg7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIHotaW5kZXg6IDA7XHJcbn1cclxuXHJcbi5hcHBseV9mb3JfcGF5b3V0X2FyZWEgLnNoYXBlX2JveCBpbWcge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxufVxyXG5cclxuLmFwcGx5X2Zvcl9wYXlvdXQge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nOiA5MHB4IDBweDtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB6LWluZGV4OiAxO1xyXG59XHJcblxyXG4uYXBwbHlfZm9yX3BheW91dCBoMSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBwYWRkaW5nOiAwIDA7XHJcbiAgICBtYXJnaW46IDAgMCAxNXB4O1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uYXBwbHlfZm9yX3BheW91dCAuZm9ybV9ib3gge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtaW4taGVpZ2h0OiAzNThweDtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogNTBweCAyNXB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcclxuICAgIGJveC1zaGFkb3c6IDAgNXB4IDVweCByZ2IoMTQ2IDE0NiAxNDYgLyAyNCUpO1xyXG4gICAgbWFyZ2luOiAwIDAgMzBweDtcclxufVxyXG5cclxuLmZvcm0tZ3JvdXAsIC5mb3JtLWNoZWNre1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgbWFyZ2luOiAwIDAgMjBweDtcclxufVxyXG4uZm9ybS1ncm91cCBsYWJlbCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBtYXJnaW46IDAgMCA4cHg7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi5mb3JtLWNvbnRyb2wge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQ2cHg7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNiZmJmYmY7XHJcbiAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgcGFkZGluZzogMTBweCAwcHg7XHJcbn1cclxudGV4dGFyZWEuZm9ybS1jb250cm9se1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGhlaWdodDogMTIzcHg7XHJcbn1cclxuLmJ0bntcclxuICAgIGJhY2tncm91bmQ6ICM4NmJlNDE7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjODZiZTQxO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDE1cHg7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbn1cclxuLmFwcGx5X2Zvcl9wYXlvdXQgLmZvcm1fYm94IGgzIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHBhZGRpbmc6IDAgMDtcclxuICAgIG1hcmdpbjogMCAwIDI1cHg7XHJcbiAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmZvcm17XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBtYXJnaW46IDAgMCAyMHB4O1xyXG59XHJcbi5mb3JtOmxhc3QtY2hpbGR7XHJcbiAgICBtYXJnaW46IDAgMCAwO1xyXG59XHJcblxyXG4uYXBwbHlfZm9yX3BheW91dF9hcmVhIC5sb2dvIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWF4LXdpZHRoOiAxMTJweDtcclxuICAgIG1hcmdpbjogMCBhdXRvIDEwcHg7XHJcbn1cclxuLmFwcGx5X2Zvcl9wYXlvdXRfYXJlYSAubG9nbyBpbWd7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbn1cclxuLmZvcm0tY2hlY2sgbGFiZWwuZm9ybS1jaGVjay1sYWJlbHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4uYnRuLWxpbmt7XHJcbiAgICBjb2xvcjogIzFjYTNlZDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBwYWRkaW5nOiAwIDA7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLmZvcm0tY2hlY2sgLmJ0bi1saW5re1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcbi5hcHBseV9mb3JfcGF5b3V0IC5hY2NvdW50e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5hcHBseV9mb3JfcGF5b3V0IC5hY2NvdW50IHB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDAgMDtcclxuICAgIG1hcmdpbjogMCAwIDJweDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBjb2xvcjogIzZjNmM2YztcclxufSJdfQ== */");

/***/ }),

/***/ 76770:
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" <ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Login</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n    <div class=\"apply_for_payout_area\">\n        <!-- <div class=\"shape_box\"><img src=\"assets/images/sape10.png\" alt=\"sape10\" title=\"\" /></div> -->\n        <div class=\"apply_for_payout\">\n            <div class=\"container\">\n                <!-- <div class=\"logo\"><img src=\"assets/images/inner-logo.png\" alt=\"logo\" title=\"\" /></div> -->\n                <h1>Fill the Below information to Log In</h1>\n                <div class=\"form_box\">\n                    <div class=\"form\">\n                        <h3>Login</h3>\n                        <div class=\"form-group\">\n                            <input type=\"text\" class=\"form-control\" placeholder=\"Enter your username\"  [(ngModel)]=\"email\" [ngModelOptions]=\"{standalone: true}\"/>\n                        </div>\n                        <div class=\"form-group\" style=\"position: relative;\">\n                             <input  type=\"{{ isActive ? 'password' : 'text' }}\"  class=\"form-control\" placeholder=\"Enter your Password\" [(ngModel)]=\"password\" [ngModelOptions]=\"{standalone: true}\">\n                        <div *ngIf=\"isActive\" style=\"position: absolute;\n                        right: 0;\n                        top: 0px;\n                        bottom: 0px;\n                        width: 38px;\n                        /* background: red; */\n                        text-align: center;\n                        padding-top: 10px;\" (click)=\"inputChange(1)\"><ion-icon name=\"eye-off-outline\" style=\"font-size: 26px;\"></ion-icon>\n                        </div>\n                            \n                            <div *ngIf=\"!isActive\" style=\"position: absolute;\n                        right: 0;\n                        top: 0px;\n                        bottom: 0px;\n                        width: 38px;\n                        /* background: red; */\n                        text-align: center;\n                        padding-top: 10px;\" (click)=\"inputChange(0)\"><ion-icon name=\"eye-outline\" style=\"font-size: 26px;\"></ion-icon>\n                        </div>\n                            \n                        </div>\n                        <div class=\"form-check\">\n                            <!-- <label class=\"form-check-label\">\n                                <input type=\"checkbox\" class=\"form-check-input\" value=\"\">Keep me logged in\n                            </label> -->\n                          <!--  <button class=\"btn-link\" routerLink=\"/forgot-password\">Forgot Password?</button> -->\n                        </div>\n                       <button class=\"btn\" (click)=\"login()\">login</button>\n                    </div>\n                </div>\n              \n            </div>\n        </div>\n    </div>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map