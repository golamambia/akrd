(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_profile_profile_module_ts"],{

/***/ 75434:
/*!***************************************************!*\
  !*** ./src/app/profile/profile-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 29755);




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 47350:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 75434);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 29755);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 29755:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile.page.html */ 52907);
/* harmony import */ var _profile_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.scss */ 70231);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ 45103);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ 5901);
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ 41765);
/* harmony import */ var _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/base64/ngx */ 43170);
/* harmony import */ var src_app_event_events_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/event/events.service */ 1479);




//import { Http, Headers, RequestOptions } from '@angular/http';




















let ProfilePage = class ProfilePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, route, datePipe, nativeGeocoder, geolocation, camera, photoViewer, base64, sanitizer, file, actionSheetController, events) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.route = route;
        this.datePipe = datePipe;
        this.nativeGeocoder = nativeGeocoder;
        this.geolocation = geolocation;
        this.camera = camera;
        this.photoViewer = photoViewer;
        this.base64 = base64;
        this.sanitizer = sanitizer;
        this.file = file;
        this.actionSheetController = actionSheetController;
        this.events = events;
        this.image_path = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.project = '';
        this.category = '';
        this.start_time = '';
        this.start_timenw = '';
        this.end_time = '';
        this.work_description = '';
        this.clientID = '';
        this.clientCode = '';
        this.newMin = '';
        this.address = '';
        this.current_address = '';
        this.expense_amount = '';
        this.stindex = '';
        this.depositImage = "";
        this.depositImage2 = "";
        this.projecy_list = "";
        this.category_list = '';
        this.category_text = '';
        this.subcategory_list = '';
        this.subcategory_text = '';
        this.subcategory = '';
        this.project_text = '';
        this.proof_doc = 'yes';
        this.imagePickerOptions = {
            maximumImagesCount: 1,
            quality: 50
        };
        this.bank_name = '';
        this.blood_group = '';
        this.email = '';
        this.full_name = '';
        this.ifsc_code = '';
        this.phone = '';
        this.account_no = '';
        this.password = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.stindex = this.route.snapshot.paramMap.get('id');
        this.isToggled = false;
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        //this.storage.set("mintime",'09:30');
        //  this.storage.clear();s
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    submit_mode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            yield loading.present();
            let localarray = {
                "userid": this.userId,
                "depositImage2": this.depositImage2,
                "password": this.password,
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'change-user-password', JSON.stringify(localarray), { headers: headers })
                .subscribe((res) => {
                console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.password = '';
                    this.alertController.create({
                        message: 'Successfully updated',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    this.events.publish('user:profile', true);
                    // this.navCtrl.back();
                }
                else {
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            yield loading.present();
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'get-user-details', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.bank_name = res.response_data.bank_name;
                    this.blood_group = res.response_data.blood_group;
                    this.email = res.response_data.email;
                    this.full_name = res.response_data.full_name;
                    this.ifsc_code = res.response_data.ifsc_code;
                    this.phone = res.responres.response_data.phone;
                    this.account_no = res.responres.response_data.account_no;
                    this.depositImage = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path + res.response_data.profile_pic;
                }
                else {
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    deposit_slip_image(sourceType) {
        let options = {
            quality: 30,
            targetWidth: 768,
            targetHeight: 1360,
            // allowEdit: true,
            destinationType: this.camera.DestinationType.FILE_URI,
            sourceType: sourceType,
            //sourceType: this.camera.PictureSourceType.CAMERA,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then(imageData => {
            this.base64.encodeFile(imageData).then((base64File) => {
                this.depositImage = base64File;
                this.depositImage2 = base64File;
                //this.proof_doc=base64File;
                // this.form.controls.ddImage = this.ddImage;				
            }, (err) => {
                //	this.showToastWithCloseButton("Image capture failed. Please try again.");
            });
        }, error => {
            console.log('ERROR -> ' + JSON.stringify(error));
        });
    }
    selectImage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: "Select Image source",
                buttons: [{
                        text: 'Load from Library',
                        handler: () => {
                            this.deposit_slip_image(this.camera.PictureSourceType.PHOTOLIBRARY);
                        }
                    },
                    {
                        text: 'Use Camera',
                        handler: () => {
                            this.deposit_slip_image(this.camera.PictureSourceType.CAMERA);
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel'
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    imageViewer(imageToView, text = '') {
        this.photoViewer.show(imageToView, text);
    }
};
ProfilePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_16__.DatePipe },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__.NativeGeocoder },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__.Geolocation },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__.Camera },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__.PhotoViewer },
    { type: _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_9__.Base64 },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.DomSanitizer },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__.File },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.ActionSheetController },
    { type: src_app_event_events_service__WEBPACK_IMPORTED_MODULE_10__.Events }
];
ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-profile',
        template: _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfilePage);



/***/ }),

/***/ 70231:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9maWxlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 52907:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Profile</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <div padding style=\"margin-top: 15px;\">\n            \n      <div class=\"form-group\">\n        <label>Name</label>\n      \n        <input type=\"text\" [(ngModel)]=\"full_name\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\" >\n      </div>\n         <div class=\"form-group\">\n        <label>Email</label>\n      \n        <input type=\"text\" [(ngModel)]=\"email\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n  <div class=\"form-group\">\n        <label>Phone</label>\n      \n        <input type=\"text\" [(ngModel)]=\"phone\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n      <div class=\"form-group\">\n        <label>Blood Group</label>\n      \n        <input type=\"text\" [(ngModel)]=\"blood_group\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n   \n       <div class=\"form-group\">\n        <label>Bank Name</label>\n      \n        <input type=\"text\" [(ngModel)]=\"bank_name\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n       <div class=\"form-group\">\n        <label>Account No</label>\n      \n        <input type=\"text\" [(ngModel)]=\"account_no\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n       <div class=\"form-group\">\n        <label>Ifs Code</label>\n      \n        <input type=\"text\" [(ngModel)]=\"ifsc_code\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control readonly\" placeholder=\"\"  >\n      </div>\n       <div class=\"form-group\">\n        <label>Change Password</label>\n      \n        <input type=\"password\" [(ngModel)]=\"password\" [ngModelOptions]=\"{standalone: true}\" class=\"form-control\" placeholder=\"Enter password\"  >\n      </div>\n  <ion-row >\n    <ion-col size=\"3\">\n  <div class=\"form-group\">\n    <label style=\"margin-top: -12px !important;left: 0;\">Photo</label>\n   \n    <div class=\"form-control\" style=\"height: 70px;padding-left: 22px;\"><span (click)=\"selectImage()\" ><ion-icon style=\"font-size: 35px;\n      color: #00f1b0;\" name=\"camera-outline\"></ion-icon></span></div>\n     </div>\n    </ion-col>\n    <ion-col size=\"2\">\n      <div class=\"image_border\" *ngIf=\"depositImage\"  style=\"height: 70px;\">\n        <img [src]=\"sanitizer.bypassSecurityTrustUrl(depositImage)\" (click)=\"imageViewer(depositImage)\">\n      </div>\n    </ion-col>\n      \n  </ion-row>\n   \n  \n          </div>\n         \n        </ion-col>\n      </ion-row>\n    </ion-grid>\n \n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-row>\n  <ion-col>\n  \n    <div padding>\n      <button class=\"btn\"  (click)=\"submit_mode()\">Update</button>\n    </div>\n  </ion-col>\n  </ion-row>\n  </ion-footer>");

/***/ })

}]);
//# sourceMappingURL=src_app_profile_profile_module_ts.js.map