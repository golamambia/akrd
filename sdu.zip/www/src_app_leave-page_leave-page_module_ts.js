(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_leave-page_leave-page_module_ts"],{

/***/ 95163:
/*!********************************************************!*\
  !*** ./src/app/component/setting/setting.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingComponent": () => (/* binding */ SettingComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_setting_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./setting.component.html */ 51014);
/* harmony import */ var _setting_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./setting.component.scss */ 88359);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 34595);





let SettingComponent = class SettingComponent {
    constructor(popoverController, navCtrl) {
        this.popoverController = popoverController;
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        // this.siteInfo = this.navParams.get('site');
        //console.log(this.site);
    }
    wifiSetting() {
        // code for setting wifi option in apps
        this.popoverController.dismiss();
    }
    logout() {
        // code for logout
        this.popoverController.dismiss();
    }
    eventFromPopover() {
        this.popoverController.dismiss('edupala.com');
    }
    popDismiss(page) {
        this.popoverController.dismiss();
        this.navCtrl.navigateForward('/' + page);
    }
};
SettingComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
SettingComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-setting',
        template: _raw_loader_setting_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_setting_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SettingComponent);



/***/ }),

/***/ 19530:
/*!*********************************************************!*\
  !*** ./src/app/leave-page/leave-page-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePageRoutingModule": () => (/* binding */ LeavePagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _leave_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./leave-page.page */ 17775);




const routes = [
    {
        path: '',
        component: _leave_page_page__WEBPACK_IMPORTED_MODULE_0__.LeavePagePage
    }
];
let LeavePagePageRoutingModule = class LeavePagePageRoutingModule {
};
LeavePagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LeavePagePageRoutingModule);



/***/ }),

/***/ 60692:
/*!*************************************************!*\
  !*** ./src/app/leave-page/leave-page.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePageModule": () => (/* binding */ LeavePagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _leave_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./leave-page-routing.module */ 19530);
/* harmony import */ var _leave_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leave-page.page */ 17775);







let LeavePagePageModule = class LeavePagePageModule {
};
LeavePagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _leave_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.LeavePagePageRoutingModule
        ],
        declarations: [_leave_page_page__WEBPACK_IMPORTED_MODULE_1__.LeavePagePage]
    })
], LeavePagePageModule);



/***/ }),

/***/ 17775:
/*!***********************************************!*\
  !*** ./src/app/leave-page/leave-page.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePage": () => (/* binding */ LeavePagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_leave_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./leave-page.page.html */ 27781);
/* harmony import */ var _leave_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leave-page.page.scss */ 68436);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _component_setting_setting_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../component/setting/setting.component */ 95163);




//import { Http, Headers, RequestOptions } from '@angular/http';












let LeavePagePage = class LeavePagePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe, actionSheetController, popoverController
    //public events: Events
    ) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.actionSheetController = actionSheetController;
        this.popoverController = popoverController;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.search_date = '';
        this.search_category = '';
        this.search_status = '';
        this.total_leave = '';
        this.search_leavecat = '';
        this.search_leavetype = '';
        this.customPickerOptionFrom = {
            buttons: [
                {
                    text: 'clear',
                    handler: () => {
                        this.search_date = '';
                        this.reloadDepositData();
                        //this.ionCancel.emit();
                    }
                },
                {
                    text: 'cancel',
                    role: 'cancel',
                    handler: () => {
                        //console.log(123);
                    }
                },
                {
                    text: 'Done',
                    handler: (data) => {
                        // console.log(data);
                        var dt = data.year.value + '-' + data.month.value + '-' + data.day.text;
                        //convertDataToISO(this.datetimeValue);
                        this.search_date = dt;
                        this.reloadDepositData();
                        // console.log(this.search_date);
                    }
                }
            ]
        };
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
        this.reloadDepositData();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                "leave_type": this.search_leavecat,
                "leaveday_type": this.search_leavetype,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-leave-application-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_leave = res.total_leave;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                "leave_type": this.search_leavecat,
                "leaveday_type": this.search_leavetype,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-leave-application-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                event.target.complete();
                //loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_leave = res.total_leave;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectDate(dt) {
        // this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        // this.reloadDepositData();
    }
    selectStatus(id) {
        this.search_status = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectCategory(id) {
        this.search_leavecat = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectLeavetype(id) {
        this.search_leavetype = id;
        //console.log(id);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    detailsView(desc) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var button_array = [
                { text: 'Reason : ' + desc },
            ];
            const actionSheet = yield this.actionSheetController.create({
                header: "Short Details",
                cssClass: 'action-sheet-button22',
                buttons: button_array,
            });
            yield actionSheet.present();
        });
    }
    settingsPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const siteInfo = { id: 1, name: 'edupala' };
            const popover = yield this.popoverController.create({
                component: _component_setting_setting_component__WEBPACK_IMPORTED_MODULE_4__.SettingComponent,
                event: ev,
                cssClass: 'popover_setting',
                componentProps: {
                    site: siteInfo
                },
                translucent: true
            });
            popover.onDidDismiss().then((result) => {
                //console.log(result.data);
            });
            return yield popover.present();
            /** Sync event from popover component */
        });
    }
};
LeavePagePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController }
];
LeavePagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-leave-page',
        template: _raw_loader_leave_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_leave_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LeavePagePage);



/***/ }),

/***/ 88359:
/*!**********************************************************!*\
  !*** ./src/app/component/setting/setting.component.scss ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZXR0aW5nLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 68436:
/*!*************************************************!*\
  !*** ./src/app/leave-page/leave-page.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-grid {\n  margin-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.form-group {\n  margin: 0 0 10px !important;\n}\n\n.add-btn {\n  --ion-color-base: #071662 !important;\n  --ion-color-base-rgb: var(--ion-color-primary-rgb, 56, 128, 255) !important;\n  --ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;\n  --ion-color-contrast-rgb: var(\n    --ion-color-primary-contrast-rgb,\n    255,\n    255,\n    255\n  ) !important;\n  --ion-color-shade: #071662 !important;\n  --ion-color-tint: #071662 !important;\n  font-size: 12px;\n  font-family: \"Inter Regular\";\n  font-weight: 600;\n}\n\n.add-btn-icon {\n  color: #3bf5c2;\n  font-size: 30px;\n}\n\n.ref_btn {\n  padding-top: 8px !important;\n  padding-left: 9px !important;\n  border-radius: 9px !important;\n}\n\n.ion-badge {\n  right: 5px !important;\n}\n\n.ion-badge-suc {\n  right: 5px !important;\n}\n\n.rowcls {\n  height: 90px;\n}\n\n.inh2 {\n  color: #00b0ff;\n  font-size: 15px !important;\n}\n\n.action-sheet-button22.action-sheet-button {\n  min-height: 147px !important;\n  overflow-y: scroll !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxlYXZlLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwyQkFBQTtBQUVGOztBQUFBO0VBQ0Usb0NBQUE7RUFDQSwyRUFBQTtFQUNBLHdFQUFBO0VBQ0E7Ozs7O2NBQUE7RUFNQSxxQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7QUFHRjs7QUFEQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBSUY7O0FBRkE7RUFDRSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUFLRjs7QUFIQTtFQUNFLHFCQUFBO0FBTUY7O0FBSkE7RUFDRSxxQkFBQTtBQU9GOztBQUxBO0VBQ0UsWUFBQTtBQVFGOztBQU5BO0VBQ0UsY0FBQTtFQUNBLDBCQUFBO0FBU0Y7O0FBUEE7RUFDRSw0QkFBQTtFQUNBLDZCQUFBO0FBVUYiLCJmaWxlIjoibGVhdmUtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTBweDtcclxufVxyXG4uZm9ybS1ncm91cCB7XHJcbiAgbWFyZ2luOiAwIDAgMTBweCAhaW1wb3J0YW50O1xyXG59XHJcbi5hZGQtYnRuIHtcclxuICAtLWlvbi1jb2xvci1iYXNlOiAjMDcxNjYyICFpbXBvcnRhbnQ7XHJcbiAgLS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiwgNTYsIDEyOCwgMjU1KSAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDtcclxuICAtLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcihcclxuICAgIC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QtcmdiLFxyXG4gICAgMjU1LFxyXG4gICAgMjU1LFxyXG4gICAgMjU1XHJcbiAgKSAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLXNoYWRlOiAjMDcxNjYyICFpbXBvcnRhbnQ7XHJcbiAgLS1pb24tY29sb3ItdGludDogIzA3MTY2MiAhaW1wb3J0YW50O1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBmb250LWZhbWlseTogXCJJbnRlciBSZWd1bGFyXCI7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4uYWRkLWJ0bi1pY29uIHtcclxuICBjb2xvcjogIzNiZjVjMjtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbn1cclxuLnJlZl9idG4ge1xyXG4gIHBhZGRpbmctdG9wOiA4cHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWxlZnQ6IDlweCAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDlweCAhaW1wb3J0YW50O1xyXG59XHJcbi5pb24tYmFkZ2Uge1xyXG4gIHJpZ2h0OiA1cHggIWltcG9ydGFudDtcclxufVxyXG4uaW9uLWJhZGdlLXN1YyB7XHJcbiAgcmlnaHQ6IDVweCAhaW1wb3J0YW50O1xyXG59XHJcbi5yb3djbHMge1xyXG4gIGhlaWdodDogOTBweDtcclxufVxyXG4uaW5oMiB7XHJcbiAgY29sb3I6ICMwMGIwZmY7XHJcbiAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLmFjdGlvbi1zaGVldC1idXR0b24yMi5hY3Rpb24tc2hlZXQtYnV0dG9uIHtcclxuICBtaW4taGVpZ2h0OiAxNDdweCAhaW1wb3J0YW50O1xyXG4gIG92ZXJmbG93LXk6IHNjcm9sbCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 51014:
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/component/setting/setting.component.html ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n\t<ion-item  (click)=\"popDismiss('home')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"home-outline\" class=\"item-icon\"></ion-icon>Home\n\t</ion-item>\n\t<ion-item  (click)=\"popDismiss('generale-leave')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"item-icon\"></ion-icon> Gen Leave Apply\n\t</ion-item>\n\t<ion-item (click)=\"popDismiss('medical-leave')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"item-icon\"></ion-icon> Med Leave Apply\n\t</ion-item>\n\t<ion-item (click)=\"popDismiss('compact-leave')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"item-icon\"></ion-icon>  Comp Leave Apply\n\t</ion-item>\n\t \n</ion-content>");

/***/ }),

/***/ 27781:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/leave-page/leave-page.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n\n <ion-buttons slot=\"primary\">\n            <ion-button (click)=\"settingsPopover()\">\n              <ion-icon style=\"color:white;\" slot=\"icon-only\" ios=\"ellipsis-horizontal\" md=\"ellipsis-vertical\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n          <ion-title class=\"toolbar-title\">My Leave</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n  <ion-refresher (ionRefresh)=\"doRefresh($event)\" slot=\"fixed\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content style=\"margin-top: 150px;\"></ion-refresher-content>\n  </ion-refresher>\n    <ion-grid>\n      <div>\n            <ion-row>\n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\" style=\"font-size: 12px;\">Total Gen Leave</span> \n                 <p class=\"title-date\"> {{total_leave.gen}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n             \n             \n            </ion-col>\n           \n                \n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                  <ion-row>\n                    <ion-col size=\"2\">\n                  <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                     </ion-col>\n                     <ion-col size=\"10\">\n                  <div class=\"right-box-margin\">   <span class=\"title-today\" style=\"font-size: 12px;\">Total Med Leave</span> \n                   <p class=\"title-date\">{{total_leave.med}}</p>\n                  </div>\n                  </ion-col>\n                  </ion-row>\n                  </div>\n                \n                </ion-col>\n               \n                </ion-row>\n              </div>\n            \n                  \n              <div class=\"card-box\" style=\"padding-top: 11px;\">\n                <ion-row >\n                  <ion-col align-self-center size=\"6\" >\n                    <div class=\"form-group\">\n                      <label>Leave Type</label>\n                       <select #LA (change)=\"selectLeavetype(LA.value)\" class=\"form-control\" [(ngModel)]=\"search_leavetype\" [ngModelOptions]=\"{standalone: true}\">\n                      <option value=\"\">All</option>\n            <option  value=\"fullday\">Full Day</option>\n            <option value=\"1sthalf\">1st Half</option>\n            <option value=\"2ndhalf\">2nd Half</option>\n                    </select>\n                      <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n                  </div>\n                   \n                  \n             </ion-col>\n             <ion-col align-self-center size=\"6\" >\n              <div class=\"form-group\"  >\n                <label class=\"time-lable\">Date</label>\n              \n                <ion-datetime [pickerOptions]=\"customPickerOptionFrom\" #D (ionChange)=\"selectDate(D.value)\" class=\"form-control\" placeholder=\"Date (D/M/Y)\" [min]=\"minDate\"  displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              </div>\n              \n           \n            </ion-col>\n            \n              <ion-col align-self-center size=\"6\" >\n                <div class=\"form-group\">\n                  <label>Category</label>\n                  <select  class=\"form-control\" #CA (change)=\"selectCategory(CA.value)\"  placeholder=\"Select\" [(ngModel)]=\"search_leavecat\" [ngModelOptions]=\"{standalone: true}\">\n                  <option value=\"\">All</option>\n                  <option value=\"gen\">General</option>\n                  <option value=\"med\">Medical</option>\n                  <option value=\"comp\">Comp</option>\n                </select>\n                   \n                  <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n              </div>\n                \n         </ion-col>\n         <ion-col align-self-center size=\"6\" >\n          <div class=\"form-group\">\n            <label>Status</label>\n             <select #S (change)=\"selectStatus(S.value)\" class=\"form-control\" [(ngModel)]=\"search_status\" [ngModelOptions]=\"{standalone: true}\">\n              \n           <option value=\"\">All</option>\n                        <option value=\"active\">Success</option>\n                        <option value=\"inactive\">Pending</option>\n                        <option value=\"reject\">Reject</option>\n          </select>\n            <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n        </div>\n               \n        </ion-col>\n        </ion-row>\n           </div>\n                \n           <div *ngFor=\"let inneritem of depositData; let i = index\" class=\"card-box\" style=\"padding-left: 0;\">\n                  \n                    <ion-row (click)=\"detailsView(inneritem.la_description)\" class=\"rowcls\">\n                      <ion-col size=\"1\"  class=\"{{inneritem.la_status}}-col\">\n                        <h4 class=\"status-title\"><ion-badge  class=\"ion-badge-suc\" *ngIf=\"inneritem.la_status=='active'\">Success</ion-badge>\n                          <ion-badge class=\"ion-badge\" *ngIf=\"inneritem.la_status=='inactive'\">Pending</ion-badge>\n                          <ion-badge  class=\"ion-badge\" *ngIf=\"inneritem.la_status=='reject'\">Reject</ion-badge></h4>\n                      \n                      </ion-col>\n                      <ion-col size=\"11\" style=\"padding-left:11px\">\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                           <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Leave day: </span><br>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='fullday'\" class=\"inh2\">Full Day</span>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='1sthalf'\" class=\"inh2\">1st Half</span>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='2ndhalf'\" class=\"inh2\">2nd Half</span>\n                              </h2>\n                            </ion-col>\n                           <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Category </span><br>\n                                <span *ngIf=\"inneritem.la_leave_type=='med'\" class=\"inh2\">Medical</span>\n                              <span *ngIf=\"inneritem.la_leave_type=='gen'\" class=\"inh2\">General</span>\n                              <span *ngIf=\"inneritem.la_leave_type=='comp'\" class=\"inh2\">Comp</span>\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Date: </span><br>\n                                {{inneritem.la_leaveday | date:'MMM dd, yy'}}\n                              </h2>\n                            </ion-col>\n                                                     \n                            \n                          </ion-row>\n                          \n                        </ion-label>\n                      </ion-col>\n                    \n                  \n                </ion-row>\n             \n                </div>\n          \n          \n    </ion-grid>\n    \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_leave-page_leave-page_module_ts.js.map